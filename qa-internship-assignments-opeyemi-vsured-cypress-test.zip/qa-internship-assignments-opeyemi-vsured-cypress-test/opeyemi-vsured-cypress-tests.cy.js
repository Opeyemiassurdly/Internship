describe('Vsured Login Page Negative Scenarios', () => {
  beforeEach(() => {
    cy.visit('https://vsured-frontend.vercel.app/login'); 
    cy.get('.right-0').click(); 
  });

  it('Verify that invalid email and password are unauthenticated', () => {
    cy.get('.relative > :nth-child(1) > .grey-input').type('opeyemiintern@assurdly.com');
    cy.get('.w-full > .grey-input').type('opeyemiintern');
    cy.get('button[type="submit"]').click();
    cy.get('.Toastify__toast-body > div').should('be.visible'); 
  });

  
  it('Verify login with unconventional characters in email field', () => {
    cy.get('.relative > :nth-child(1) > .grey-input').type('user!@#$%^&*()=+{}[]|;:"<>,?/`~@example.com');
    cy.get('.w-full > .grey-input').type('password123');
    cy.get('button[type="submit"]').click();
    cy.get('.Toastify__toast-body > div').should('be.visible').should('be.visible'); 
  });

  it('Verify login with unconventional characters in password field', () => {
    cy.get('.relative > :nth-child(1) > .grey-input').type('opeyemiintern@assurdly.com');
    cy.get('.w-full > .grey-input').type('p@$$w0rd!@#$%^&*()=+{}[]|;:"<>,?/`~');
    cy.get('button[type="submit"]').click();
    cy.get('.Toastify__toast-body > div').should('be.visible'); 
  });

  it('Verify login with SQL injection attempt', () => {
    cy.get('.relative > :nth-child(1) > .grey-input').type('\' OR 1=1 --');
    cy.get('.w-full > .grey-input').type('\' OR 1=1 --');
    cy.get('button[type="submit"]').click();
    cy.get('.Toastify__toast-body > div').should('be.visible'); 
  });

  it('Verify login with XSS attempt', () => {
    cy.get('.relative > :nth-child(1) > .grey-input').type('<script>alert("XSS")</script>');
    cy.get('.w-full > .grey-input').type('<script>alert("XSS")</script>');
    cy.get('button[type="submit"]').click();
    cy.get('.Toastify__toast-body > div').should('be.visible'); 
  });

  it('Verify login with extremely long email and password', () => {
    const longString = 'a'.repeat(1000);
    cy.get('.relative > :nth-child(1) > .grey-input').type(`${longString}@example.com`);
    cy.get('.w-full > .grey-input').type(longString);
    cy.get('button[type="submit"]').click();
    cy.get('.Toastify__toast-body > div').should('be.visible'); 
  });
});