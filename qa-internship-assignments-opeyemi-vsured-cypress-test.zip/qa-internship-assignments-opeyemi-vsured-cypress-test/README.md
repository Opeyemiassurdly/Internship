# qa-internship-assignments
This repository contains assignments for QA interns to practice and demonstrate their skills in API automation and end-to-end testing using Cypress. The assignments are structured to help interns integrate automated tests into a CI/CD pipeline using GitHub Actions and generate detailed test reports with Allure.
